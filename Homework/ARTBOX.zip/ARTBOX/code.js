onEvent("Canvas1button", "click", function( ) {
  setScreen("screen2");
  playSound("assets/category_explosion/melodic_loss_6.mp3", false);
  setActiveCanvas("canvas1");
});
onEvent("Canvas3button", "click", function( ) {
  setScreen("screen4");
  playSound("assets/category_human/character_calvin_good_luck_3.mp3", false);
  setActiveCanvas("canvas3");
});
onEvent("Canvas2button", "click", function( ) {
  setScreen("screen3");
  playSound("assets/category_poof/puzzle_game_poof_chatter_03.mp3", false);
  setActiveCanvas("canvas2");
});
onEvent("canvas1", "mousemove", function(event ) {
  circle(event.x, event.y, 8);
});
onEvent("canvas2", "mousemove", function(event) {
  circle(event.x, event.y, 10);
});
onEvent("canvas3", "mousemove", function(event) {
  circle(event.x, event.y, 12);
});
onEvent("button4", "click", function( ) {
  setScreen("screen5");
});
onEvent("button5", "click", function( ) {
  setScreen("screen1");
});
onEvent("Backbutt1on", "click", function( ) {
  setScreen("screen1");
});
onEvent("backbutton7", "click", function( ) {
  setScreen("screen1");
});
